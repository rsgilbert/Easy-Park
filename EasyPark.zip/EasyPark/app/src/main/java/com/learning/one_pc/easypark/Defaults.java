package com.learning.one_pc.easypark;

public class Defaults {
    private double radius = 1.6;
    public Defaults(){

    }

    public double getRadius() {
        return radius;
    }

}
