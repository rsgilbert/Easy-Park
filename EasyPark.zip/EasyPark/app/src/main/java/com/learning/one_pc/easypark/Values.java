package com.learning.one_pc.easypark;

public class Values {
    private static double radius = 1.6;
    public Values(){

    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
}
